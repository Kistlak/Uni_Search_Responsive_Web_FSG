<?php
    $dbCon = mysqli_connect("localhost", "root", "", "a3075631_slsoc");

    if (mysqli_connect_errno()) {
        echo "Failed to connect: " . mysqli_connect_error();
    }
?>
